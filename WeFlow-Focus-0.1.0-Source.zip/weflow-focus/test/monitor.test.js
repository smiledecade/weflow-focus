const test = require('node:test');
const assert = require('node:assert/strict');
const { normalizeMessage, keywordHits, isAllowed, dedupe } = require('../src/monitor');

test('normalizes and filters messages', () => {
  const msg = normalizeMessage({ sessionId: '1@chatroom', rawid: 7, content: '交易所调整保证金' });
  assert.equal(msg.rawid, '7');
  assert.equal(isAllowed(msg, [{ id: '1@chatroom' }]), true);
  assert.deepEqual(keywordHits(msg.content, ['保证金', '事故']), ['保证金']);
});

test('deduplicates by event and rawid', () => {
  const input = [{ event:'message.new', rawid:'1' }, { event:'message.new', rawid:'1' }, { event:'message.revoke', rawid:'1' }];
  assert.equal(dedupe(input).length, 2);
});
