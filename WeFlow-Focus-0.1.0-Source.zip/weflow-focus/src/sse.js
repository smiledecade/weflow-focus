class SSEClient {
  constructor({ onEvent, onStatus }) {
    this.onEvent = onEvent;
    this.onStatus = onStatus;
    this.abort = null;
    this.retryTimer = null;
    this.running = false;
  }
  start(baseUrl, token) {
    this.stop();
    this.running = true;
    this.connect(baseUrl, token);
  }
  stop() {
    this.running = false;
    if (this.abort) this.abort.abort();
    if (this.retryTimer) clearTimeout(this.retryTimer);
    this.abort = null;
    this.retryTimer = null;
  }
  async connect(baseUrl, token) {
    if (!this.running) return;
    this.abort = new AbortController();
    try {
      this.onStatus({ state: 'connecting', text: '正在连接 WeFlow…' });
      const response = await fetch(`${baseUrl.replace(/\/$/, '')}/api/v1/push/messages`, {
        headers: { Authorization: `Bearer ${token}`, Accept: 'text/event-stream' },
        signal: this.abort.signal
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      this.onStatus({ state: 'online', text: '实时监控中' });
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      while (this.running) {
        const { value, done } = await reader.read();
        if (done) throw new Error('连接已结束');
        buffer += decoder.decode(value, { stream: true }).replace(/\r\n/g, '\n');
        let split;
        while ((split = buffer.indexOf('\n\n')) >= 0) {
          const block = buffer.slice(0, split);
          buffer = buffer.slice(split + 2);
          const parsed = this.parseBlock(block);
          if (parsed) this.onEvent(parsed);
        }
      }
    } catch (error) {
      if (!this.running || error.name === 'AbortError') return;
      this.onStatus({ state: 'offline', text: `连接中断，5秒后重试：${error.message}` });
      this.retryTimer = setTimeout(() => this.connect(baseUrl, token), 5000);
    }
  }
  parseBlock(block) {
    let event = 'message';
    const data = [];
    for (const line of block.split('\n')) {
      if (line.startsWith('event:')) event = line.slice(6).trim();
      if (line.startsWith('data:')) data.push(line.slice(5).trim());
    }
    if (!data.length) return null;
    try { return { event, data: JSON.parse(data.join('\n')) }; } catch { return null; }
  }
}

module.exports = { SSEClient };
