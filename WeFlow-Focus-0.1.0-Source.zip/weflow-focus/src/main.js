const { app, BrowserWindow, ipcMain, Notification, Tray, Menu, nativeImage, safeStorage } = require('electron');
const path = require('path');
const { Store } = require('./store');
const { SSEClient } = require('./sse');
const { normalizeMessage, keywordHits, isAllowed, dedupe } = require('./monitor');
const { summarize } = require('./ai');

let win;
let tray;
let store;
let sse;
let summaryTimer;
let config;
let secrets;
let messages = [];
let summaries = [];

function send(channel, value) { if (win && !win.isDestroyed()) win.webContents.send(channel, value); }
function notify(title, body) { if (Notification.isSupported()) new Notification({ title, body: body.slice(0, 500) }).show(); }

function configureSchedule() {
  if (summaryTimer) clearInterval(summaryTimer);
  const minutes = Math.max(5, Number(config.summaryMinutes) || 60);
  summaryTimer = setInterval(() => runSummary(false), minutes * 60 * 1000);
}

async function runSummary(manual) {
  const end = Math.floor(Date.now() / 1000);
  const start = end - Math.max(5, Number(config.summaryMinutes) || 60) * 60;
  const batch = messages.filter(m => m.event === 'message.new' && m.timestamp > start && m.timestamp <= end && isAllowed(m, config.groups));
  if (!batch.length) {
    if (manual) send('toast', '当前周期没有可总结的新消息');
    return;
  }
  try {
    send('summary-status', 'AI 正在生成摘要…');
    const content = await summarize(config, secrets.aiKey, batch, new Date(start * 1000).toLocaleString('zh-CN'), new Date(end * 1000).toLocaleString('zh-CN'));
    const item = { id: Date.now(), from: start, to: end, content, messageCount: batch.length };
    summaries.push(item);
    store.saveSummaries(summaries);
    send('summary', item);
    notify('WeFlow Focus 小时摘要', `已分析 ${batch.length} 条消息`);
    send('summary-status', '摘要完成');
  } catch (error) {
    send('summary-status', `摘要失败：${error.message}`);
    if (manual) notify('摘要失败', error.message);
  }
}

function startMonitor() {
  sse.stop();
  if (!secrets.weflowToken) {
    send('connection', { state: 'offline', text: '请先在设置中填写 WeFlow Token' });
    return;
  }
  sse.start(config.baseUrl, secrets.weflowToken);
}

async function createWindow() {
  win = new BrowserWindow({
    width: 1180, height: 760, minWidth: 900, minHeight: 600,
    title: 'WeFlow Focus',
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false }
  });
  await win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  win.on('close', event => {
    if (!app.isQuitting) { event.preventDefault(); win.hide(); }
  });
}

function createTray() {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32"><rect width="32" height="32" rx="8" fill="#93734a"/><text x="16" y="21" text-anchor="middle" font-family="Arial" font-size="13" font-weight="700" fill="white">WF</text></svg>`;
  const icon = nativeImage.createFromDataURL(`data:image/svg+xml;base64,${Buffer.from(svg).toString('base64')}`).resize({ width: 20, height: 20 });
  tray = new Tray(icon);
  tray.setToolTip('WeFlow Focus');
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: '打开 WeFlow Focus', click: () => win.show() },
    { label: '立即生成摘要', click: () => runSummary(true) },
    { label: '退出', click: () => { app.isQuitting = true; app.quit(); } }
  ]));
  tray.on('double-click', () => win.show());
}

app.whenReady().then(async () => {
  store = new Store(app.getPath('userData'), safeStorage);
  config = store.getConfig();
  secrets = store.getSecrets();
  messages = store.getMessages();
  summaries = store.getSummaries();
  sse = new SSEClient({
    onStatus: status => send('connection', status),
    onEvent: ({ event, data }) => {
      const message = normalizeMessage({ ...data, event });
      if (!isAllowed(message, config.groups)) return;
      if (messages.some(m => m.event === message.event && m.rawid && m.rawid === message.rawid)) return;
      const hits = keywordHits(message.content, config.keywords);
      message.keywordHits = hits;
      messages = dedupe([...messages, message]);
      const cutoff = Math.floor(Date.now() / 1000) - Math.max(1, config.retentionDays) * 86400;
      messages = messages.filter(m => m.timestamp >= cutoff);
      store.saveMessages(messages);
      send('new-message', message);
      if (hits.length) notify(`${message.groupName} · 重要关键词`, `${message.sourceName}：${message.content}`);
    }
  });
  await createWindow();
  createTray();
  configureSchedule();
  startMonitor();
});

ipcMain.handle('get-state', () => ({ config, secrets: { weflowToken: secrets.weflowToken, aiKey: secrets.aiKey }, messages, summaries }));
ipcMain.handle('save-settings', (_event, incoming) => {
  config = store.saveConfig(incoming);
  secrets = store.getSecrets();
  app.setLoginItemSettings({ openAtLogin: Boolean(config.launchAtLogin) });
  configureSchedule();
  startMonitor();
  return { ok: true };
});
ipcMain.handle('fetch-sessions', async (_event, baseUrl, token) => {
  const response = await fetch(`${baseUrl.replace(/\/$/, '')}/api/v1/sessions?limit=1000`, { headers: { Authorization: `Bearer ${token}` } });
  if (!response.ok) throw new Error(`WeFlow 返回 HTTP ${response.status}`);
  const json = await response.json();
  return (json.sessions || []).filter(s => String(s.username).endsWith('@chatroom')).map(s => ({ id: s.username, name: s.displayName || s.username }));
});
ipcMain.handle('test-weflow', async (_event, baseUrl, token) => {
  const response = await fetch(`${baseUrl.replace(/\/$/, '')}/api/v1/sessions?limit=1`, { headers: { Authorization: `Bearer ${token}` } });
  if (!response.ok) throw new Error(`连接失败：HTTP ${response.status}`);
  return { ok: true };
});
ipcMain.handle('run-summary', () => runSummary(true));

app.on('window-all-closed', () => {});
app.on('before-quit', () => { app.isQuitting = true; if (sse) sse.stop(); });
