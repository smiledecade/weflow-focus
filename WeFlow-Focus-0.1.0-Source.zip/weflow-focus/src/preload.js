const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('focusApi', {
  getState: () => ipcRenderer.invoke('get-state'),
  saveSettings: settings => ipcRenderer.invoke('save-settings', settings),
  fetchSessions: (baseUrl, token) => ipcRenderer.invoke('fetch-sessions', baseUrl, token),
  testWeFlow: (baseUrl, token) => ipcRenderer.invoke('test-weflow', baseUrl, token),
  runSummary: () => ipcRenderer.invoke('run-summary'),
  on: (channel, callback) => ipcRenderer.on(channel, (_event, value) => callback(value))
});
