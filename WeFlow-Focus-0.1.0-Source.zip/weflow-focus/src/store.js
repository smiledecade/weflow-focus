const fs = require('fs');
const path = require('path');

const defaults = {
  baseUrl: 'http://127.0.0.1:5031',
  groups: [],
  keywords: ['突发', '交易所', '保证金', '限仓', '涨停', '跌停', '停牌', '事故', '减产', '检修', '出口', '关税'],
  aiBaseUrl: 'https://api.openai.com/v1',
  aiModel: '',
  summaryMinutes: 60,
  retentionDays: 7,
  launchAtLogin: false
};

class Store {
  constructor(dir, safeStorage) {
    this.dir = dir;
    this.safeStorage = safeStorage;
    fs.mkdirSync(dir, { recursive: true });
    this.configPath = path.join(dir, 'config.json');
    this.secretPath = path.join(dir, 'secrets.json');
    this.messagePath = path.join(dir, 'messages.json');
    this.summaryPath = path.join(dir, 'summaries.json');
  }
  readJson(file, fallback) {
    try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; }
  }
  writeJson(file, value) {
    const tmp = `${file}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(value, null, 2), 'utf8');
    fs.renameSync(tmp, file);
  }
  getConfig() { return { ...defaults, ...this.readJson(this.configPath, {}) }; }
  saveConfig(config) {
    const clean = { ...defaults, ...config };
    delete clean.weflowToken;
    delete clean.aiKey;
    this.writeJson(this.configPath, clean);
    this.saveSecrets({ weflowToken: config.weflowToken || '', aiKey: config.aiKey || '' });
    return clean;
  }
  saveSecrets(secrets) {
    if (!this.safeStorage.isEncryptionAvailable()) throw new Error('Windows 安全存储当前不可用');
    const result = {};
    for (const [key, value] of Object.entries(secrets)) {
      result[key] = value ? this.safeStorage.encryptString(value).toString('base64') : '';
    }
    this.writeJson(this.secretPath, result);
  }
  getSecrets() {
    const encrypted = this.readJson(this.secretPath, {});
    const out = {};
    for (const key of ['weflowToken', 'aiKey']) {
      try {
        out[key] = encrypted[key] ? this.safeStorage.decryptString(Buffer.from(encrypted[key], 'base64')) : '';
      } catch { out[key] = ''; }
    }
    return out;
  }
  getMessages() { return this.readJson(this.messagePath, []); }
  saveMessages(messages) { this.writeJson(this.messagePath, messages.slice(-20000)); }
  getSummaries() { return this.readJson(this.summaryPath, []); }
  saveSummaries(items) { this.writeJson(this.summaryPath, items.slice(-1000)); }
}

module.exports = { Store, defaults };
