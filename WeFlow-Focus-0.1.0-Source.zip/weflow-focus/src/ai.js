function buildPrompt(messages, from, to) {
  const lines = messages.map(m => `[${new Date(m.timestamp * 1000).toLocaleString('zh-CN')}] [${m.groupName}] ${m.sourceName}: ${m.content}`);
  return `你是期货交易信息分析助手。请分析 ${from} 至 ${to} 的白名单微信群消息。\n\n要求：\n1. 提取重要事件和涉及品种；\n2. 判断偏多、偏空或中性，并明确这是信息归纳而非交易建议；\n3. 标记来源群、发言者和时间；\n4. 区分事实、观点、传闻，给出高/中/低可信度；\n5. 指出是否存在多人交叉印证；\n6. 列出值得回看原文的信息；\n7. 忽略寒暄、表情和无意义重复。\n\n消息：\n${lines.join('\n')}`;
}

async function summarize(config, apiKey, messages, from, to) {
  if (!apiKey || !config.aiModel) throw new Error('尚未配置 AI Key 或模型名称');
  const response = await fetch(`${config.aiBaseUrl.replace(/\/$/, '')}/chat/completions`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${apiKey}` },
    body: JSON.stringify({
      model: config.aiModel,
      temperature: 0.2,
      messages: [
        { role: 'system', content: '你严谨区分事实、观点和未经证实的传闻，不编造缺失信息。' },
        { role: 'user', content: buildPrompt(messages, from, to) }
      ]
    })
  });
  if (!response.ok) throw new Error(`AI 接口返回 HTTP ${response.status}: ${(await response.text()).slice(0, 300)}`);
  const json = await response.json();
  return json.choices?.[0]?.message?.content || 'AI 未返回摘要内容';
}

module.exports = { buildPrompt, summarize };
