const $ = id => document.getElementById(id);
let state = { config: {}, messages: [], summaries: [] };
let availableGroups = [];

function toast(text) { const el=$('toast'); el.textContent=text; el.classList.add('show'); setTimeout(()=>el.classList.remove('show'),2500); }
function escapeHtml(value='') { return String(value).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c])); }
function showPage(id) { document.querySelectorAll('.page,.nav').forEach(x=>x.classList.remove('active')); $(id).classList.add('active'); document.querySelector(`.nav[data-page="${id}"]`).classList.add('active'); }
function renderGroups() {
  const selected = new Set((state.config.groups||[]).map(g=>g.id));
  $('groupPicker').innerHTML = availableGroups.length ? availableGroups.map(g=>`<div class="group-row"><input type="checkbox" data-id="${escapeHtml(g.id)}" data-name="${escapeHtml(g.name)}" ${selected.has(g.id)?'checked':''}><label>${escapeHtml(g.name)}<br><span class="hint">${escapeHtml(g.id)}</span></label></div>`).join('') : '<span class="hint">没有读取到群聊</span>';
}
function renderFilter() {
  const current=$('groupFilter').value;
  $('groupFilter').innerHTML='<option value="">全部关注群</option>'+(state.config.groups||[]).map(g=>`<option value="${escapeHtml(g.id)}">${escapeHtml(g.name)}</option>`).join('');
  $('groupFilter').value=current;
}
function renderMessages() {
  const filter=$('groupFilter').value;
  const items=state.messages.filter(m=>!filter||m.sessionId===filter).slice().reverse();
  $('messageList').innerHTML=items.length?items.map(m=>`<div class="message ${(m.keywordHits||[]).length?'urgent':''}"><div class="meta">${escapeHtml(m.groupName)} · ${escapeHtml(m.sourceName)} · ${new Date(m.timestamp*1000).toLocaleString()}</div><div class="content">${escapeHtml(m.content)}</div>${(m.keywordHits||[]).length?`<div class="hits">命中：${escapeHtml(m.keywordHits.join('、'))}</div>`:''}</div>`).join(''):'<div class="empty">等待白名单群的新消息…</div>';
}
function renderSummaries() {
  const items=state.summaries.slice().reverse();
  $('summaryList').innerHTML=items.length?items.map(s=>`<article class="summary-item"><div class="meta">${new Date(s.from*1000).toLocaleString()} — ${new Date(s.to*1000).toLocaleString()} · ${s.messageCount}条消息</div><div class="summary-body">${escapeHtml(s.content)}</div></article>`).join(''):'<div class="empty">暂无摘要</div>';
}
function fillSettings() {
  const c=state.config;
  $('baseUrl').value=c.baseUrl||'http://127.0.0.1:5031'; $('weflowToken').value=state.secrets?.weflowToken||'';
  $('aiBaseUrl').value=c.aiBaseUrl||''; $('aiKey').value=state.secrets?.aiKey||''; $('aiModel').value=c.aiModel||'';
  $('summaryMinutes').value=c.summaryMinutes||60; $('retentionDays').value=c.retentionDays||7;
  $('keywords').value=(c.keywords||[]).join('，'); $('launchAtLogin').checked=Boolean(c.launchAtLogin);
}
function collectSettings() {
  const checked=[...document.querySelectorAll('#groupPicker input:checked')].map(x=>({id:x.dataset.id,name:x.dataset.name}));
  return {baseUrl:$('baseUrl').value.trim(),weflowToken:$('weflowToken').value.trim(),groups:checked.length?checked:(state.config.groups||[]),keywords:$('keywords').value.split(/[，,\n]/).map(x=>x.trim()).filter(Boolean),aiBaseUrl:$('aiBaseUrl').value.trim(),aiKey:$('aiKey').value.trim(),aiModel:$('aiModel').value.trim(),summaryMinutes:Number($('summaryMinutes').value),retentionDays:Number($('retentionDays').value),launchAtLogin:$('launchAtLogin').checked};
}

document.querySelectorAll('.nav').forEach(btn=>btn.onclick=()=>showPage(btn.dataset.page));
$('groupFilter').onchange=renderMessages;
$('testWeFlow').onclick=async()=>{try{await window.focusApi.testWeFlow($('baseUrl').value.trim(),$('weflowToken').value.trim());toast('连接成功');}catch(e){toast(e.message)}};
$('loadGroups').onclick=async()=>{try{availableGroups=await window.focusApi.fetchSessions($('baseUrl').value.trim(),$('weflowToken').value.trim());renderGroups();toast(`读取到 ${availableGroups.length} 个群聊`);}catch(e){toast(e.message)}};
$('saveSettings').onclick=async()=>{try{state.config=collectSettings();await window.focusApi.saveSettings(state.config);renderFilter();renderMessages();toast('设置已保存，正在连接');showPage('stream');}catch(e){toast(e.message)}};
$('runSummary').onclick=()=>window.focusApi.runSummary();
window.focusApi.on('connection',s=>{$('connection').className=`status ${s.state}`;$('connection').textContent=s.text});
window.focusApi.on('new-message',m=>{state.messages.push(m);renderMessages()});
window.focusApi.on('summary',s=>{state.summaries.push(s);renderSummaries()});
window.focusApi.on('summary-status',s=>$('summaryStatus').textContent=s);
window.focusApi.on('toast',toast);

(async()=>{state=await window.focusApi.getState();fillSettings();availableGroups=state.config.groups||[];renderGroups();renderFilter();renderMessages();renderSummaries();if(!state.secrets?.weflowToken)showPage('settings')})();
