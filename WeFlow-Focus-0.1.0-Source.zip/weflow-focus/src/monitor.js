function normalizeMessage(payload) {
  return {
    event: payload.event || 'message.new',
    sessionId: payload.sessionId || '',
    rawid: String(payload.rawid || ''),
    groupName: payload.groupName || payload.sessionId || '未知会话',
    sourceName: payload.sourceName || '未知成员',
    content: String(payload.content || ''),
    timestamp: Number(payload.timestamp || Math.floor(Date.now() / 1000))
  };
}

function keywordHits(content, keywords) {
  const text = String(content || '').toLowerCase();
  return (keywords || []).filter(Boolean).filter(word => text.includes(String(word).toLowerCase()));
}

function isAllowed(message, groups) {
  return (groups || []).some(group => group.id === message.sessionId);
}

function dedupe(messages) {
  const seen = new Set();
  return messages.filter(message => {
    const key = `${message.event}:${message.rawid || `${message.sessionId}:${message.timestamp}:${message.content}`}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

module.exports = { normalizeMessage, keywordHits, isAllowed, dedupe };
